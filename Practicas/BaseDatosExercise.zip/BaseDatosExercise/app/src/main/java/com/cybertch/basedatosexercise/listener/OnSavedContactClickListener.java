package com.cybertch.basedatosexercise.listener;

/**
 * Description:
 * <p>
 * Project: PreferencesExercise
 * Package: com.example.preferencesexercise.listener
 *
 * @author: Jaive Torres Pineda
 * dateCreated: 3/16/19
 * dateLastModified:
 * @version:
 * @since:
 **/
public interface OnSavedContactClickListener {

    void onClickContact();
}
