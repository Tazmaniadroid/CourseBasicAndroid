package com.cybertech.fragmentscourse.listeners;

import com.cybertech.fragmentscourse.model.Person;

public interface OnClickPersonListener {

  public void onClickPerson(Person person);
}
